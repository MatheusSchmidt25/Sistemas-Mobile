package com.example.exemploactivit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class CadastroAlunoActivity extends AppCompatActivity {

    private Button btSalvar;
    private EditText etRa;
    private EditText etNome;
    private TextView tvListaAlunos;
    private EditText etDataNascimento;
    private EditText etCpf;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_aluno);

        etNome = findViewById(R.id.etNome);
        etRa = findViewById(R.id.etRa);
        btSalvar = findViewById(R.id.btSalvar);
        tvListaAlunos = findViewById(R.id.tvListaAlunos);
        etDataNascimento = findViewById(R.id.etDataNascimento);
        etCpf = findViewById(R.id.etCpf);
        btSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarAluno();
            }
        });
        atualizarLista();
    }



    private void salvarAluno() {
        int ra=0;
        if(etRa.getText().toString().isEmpty()){
            etRa.setError("O RA do Aluno deve ser informado!!");
            return;
        }else {
            try {
                ra = Integer.parseInt(etRa.getText().toString());
            } catch (Exception ex) {
                etRa.setError("Informe um RA válido(somente numeros)!");
                return;
            }
        }
        if(etNome.getText().toString().isEmpty()){
            etNome.setError("O nome do Aluno deve ser informado!! ");
            return;
        }
        Aluno aluno = new Aluno();
        aluno.setRa(ra);
        aluno.setNome(etNome.getText().toString());
        aluno.setData(etDataNascimento.getText().toString());
        aluno.setCpf(etCpf.getText().toString());
        Controler.getInstancia().salvarAluno(aluno);

        Toast.makeText(CadastroAlunoActivity.this,
                "Aluno Cadastrado com Sucesso!!", Toast.LENGTH_SHORT).show();

        finish();
    }
    private void atualizarLista(){
        String texto="";
        ArrayList<Aluno> lista = Controler.getInstancia().retornarAlunos();
        for(Aluno aluno: lista){
            texto+= aluno.getRa()+" - "+aluno.getNome()+"\n"+aluno.getData()+" - "+aluno.getCpf()+"\n";
        }
        tvListaAlunos.setText(texto);
    }
}