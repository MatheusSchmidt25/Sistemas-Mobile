package com.example.exemploactivit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;

public class CadastroProfessor extends AppCompatActivity {

    private EditText etMatricula;
    private EditText etNome;
    private EditText etCpf;
    private EditText etDataNascimento;
    private EditText etDataAdmissao;
    private Button btSalvar;
    private TextView tvListaProfessor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro_aluno2);

        etMatricula = findViewById(R.id.etMatricula);
        etNome = findViewById(R.id.etNome);
        etCpf = findViewById(R.id.etCpf);
        etDataNascimento = findViewById(R.id.etDataNascimento);
        etDataAdmissao = findViewById(R.id.etDataNascimento);
        tvListaProfessor = findViewById(R.id.tvListaProfessor);
        btSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cadastrarProfessor();
            }

        });
        atualizarProfessor();
    }

    private void cadastrarProfessor() {
        int matricula =0;

        if(etMatricula.getText().toString().isEmpty()){
            etMatricula.setError("A matricula deve ser informado!!");
            return;
        }else {
            try {
                matricula = Integer.parseInt(etMatricula.getText().toString());
            } catch (Exception ex) {
                etMatricula.setError("Informe uma matricula válida(somente numeros)!");
                return;
            }
        }
        if(etNome.getText().toString().isEmpty()){
            etNome.setError("O nome do Professor deve ser informado!! ");
            return;
        }
        Professor professor = new Professor();
        professor .setMatricula(matricula);
        professor.setNome(etNome.getText().toString());
        professor.setData(etDataNascimento.getText().toString());
        professor.setCpf(etCpf.getText().toString());
        Controler.getInstancia();
    }

    private void atualizarProfessor(){
        String texto="";
        ArrayList<Professor> lista = Controler.getInstancia().retornarProfessor();
        for(Professor professor: lista){
            texto+="Matricula:"+ professor.getMatricula()+"\nNome:"+professor.getNome()+"\nData de Nascimento:"+professor.getData()+"\nCPF:"+professor.getCpf()+"\nData de Admissão:"+professor.getDataAdmissao()+"-------------------------------";
        }
        tvListaProfessor.setText(texto);
    }
}