package com.example.exemploactivit;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Disciplina extends AppCompatActivity {

    private EditText etDescricao;
    private EditText etCargahoraria;
    private TextView tvProfessor;
    private TextView tvErroProfessor;
    private Button btSalvar;
    private TextView tvListaDisciplinas;
    private Spinner spProfessor;
    private int posicaoSelecionada = 0;
    private ArrayList<Professor> listaProfessores;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_disciplina);

        etDescricao = findViewById(R.id.etDescricao);
        etCargahoraria = findViewById(R.id.etCargaHoraria);
        tvProfessor = findViewById(R.id.tvProfessor);
        tvErroProfessor = findViewById(R.id.tvErroProfessor);
        tvListaDisciplinas = findViewById(R.id.tvListaDisciplinas);
        btSalvar = findViewById(R.id.btSalvar);
        spProfessor = findViewById(R.id.spProfessor);

        spProfessor.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int posicao, long l) {

                if(posicao > 0){
                    posicaoSelecionada= posicao;
                    tvErroProfessor.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        btSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                salvarDisciplina();
            }
        });
        carregarProfessores();
        atualizaListaDisciplinas();
    }
    private void salvarDisciplina(){
        double cargaHoraria;

        if(etDescricao.getText().toString().isEmpty()){
            etDescricao.setError("A descrição da disciplina deve ser informada!!");
            etDescricao.requestFocus();
            return;
        }
        if(etDescricao.getText().toString().isEmpty()){
            etDescricao.setError("A carga horária deve ser informada!!");
            etDescricao.requestFocus();
            return;
        }else{
            cargaHoraria = Double.parseDouble(etCargahoraria.getText().toString());
            if(cargaHoraria <= 0){
                etCargahoraria.setError("Carga Horária deve ser maior que zero!!");
                etCargahoraria.requestFocus();
                return;
            }
        }
        if(posicaoSelecionada <= 0){
            tvErroProfessor.setVisibility(View.VISIBLE);
            return;
        }

        Professor prof = listaProfessores.get(posicaoSelecionada-1);
        Disciplinaa disciplina = new Disciplinaa();
        disciplina.setDescricao(etDescricao.getText().toString());
        disciplina.setCargaHoraria(cargaHoraria);
        disciplina.setProfessor(prof);

        Controler.getInstance().salvarDisciplina(disciplina);
        Toast.makeText(this,
                "Disciplina salva com sucesso!!",
                Toast.LENGTH_LONG).show();
    }

    private void carregaProfessores() {
        listaProfessores = Controler.getInstance().retornarProfessor();
        String[]vetProfs = new String[listaProfessores.size() + 1];
        vetProfs[0] = "Selecione o professor";
        for (int i = 0; i < listaProfessores.size(); i++) {
            Professor prof = listaProfessores.get(i);
            vetProfs[i+1] = prof.getMatricula()+" - "+prof.getNome();
        }
        ArrayAdapter adapter = new ArrayAdapter(
                Disciplina.this,
                android.R.layout.simple_dropdown_item_1line,
                vetProfs);

        spProfessor.setAdapter(adapter);

    }

    private void carregaProfessores() {
        listaProfessores = Controler.getInstance().retornarProfessor();
        String[]vetProfs = new String[listaProfessores.size() + 1];
        vetProfs[0] = "Selecione o professor";
        for (int i = 0; i < listaProfessores.size(); i++) {
            Professor prof = listaProfessores.get(i);
            vetProfs[i+1] = prof.getMatricula()+" - "+prof.getNome();
        }
        ArrayAdapter adapter = new ArrayAdapter(
                Disciplina.this,
                android.R.layout.simple_dropdown_item_1line,
                vetProfs);

        spProfessor.setAdapter(adapter);

    }

    private void atualizaListaDisciplinas(){
        ArrayList<Disciplina> lista = Controler.getInstance().retornarDisciplinas();
        String texto = "";
        for (Disciplina dis : lista) {
            Professor prof = dis.getProfessor();
            texto += dis.getDescricao()+"\n"+
                    "Carga Hr: "+dis.getCargaHoraria()+" Hr\n"+
                    "Professor: "+prof.getNome()+"\n" +
                    "---------------------------------------------\n";
        }
        tvListaDisciplinas.setText(texto);
    }

}