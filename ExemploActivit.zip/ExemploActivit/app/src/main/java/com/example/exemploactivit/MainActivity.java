package com.example.exemploactivit;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Button btCadastroAluno;
    private Button btCadastroProfessor;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btCadastroProfessor = findViewById(R.id.btCadastroProfessor);
        btCadastroProfessor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirCadastroProfessor();
            }
        });
        btCadastroAluno = findViewById(R.id.btCadastroAluno);
        btCadastroAluno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirCadastroAluno();
            }
        });
    }

    private void abrirCadastroProfessor(){
        Intent intent = new Intent(MainActivity.this,
                CadastroProfessor.class);

        startActivity(intent);
    }

    private void abrirCadastroAluno() {
        Intent intente = new Intent(MainActivity.this,
                CadastroAlunoActivity.class);

        startActivity(intente);

    }

    @Override
    protected void onRestart() {
        super.onRestart();



    }
}