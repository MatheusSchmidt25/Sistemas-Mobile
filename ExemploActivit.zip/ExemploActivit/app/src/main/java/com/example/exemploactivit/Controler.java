package com.example.exemploactivit;

import java.util.ArrayList;

public class Controler {
    private static Controler instancia;
    private ArrayList<Aluno> listaAlunos;
    private ArrayList<Professor> listaProfessor;
    private ArrayList<Disciplinaa> listaDisciplinas;

    public static Controler getInstancia(){
        if(instancia == null){
            return instancia = new Controler();
        }else{
            return instancia;
        }
    }

    private Controler(){
        listaAlunos = new ArrayList<>();
        listaProfessor = new ArrayList<>();
        listaDisciplinas = new ArrayList<>();
    }

    public static Disciplina getInstance() {
        return null;
    }


    public void salvarAluno(Aluno aluno){

        listaAlunos.add(aluno);
    }
    public ArrayList<Aluno> retornarAlunos(){

        return listaAlunos;
    }

    public void atualizarProfessor(Professor professor){
        listaProfessor.add(professor);
    }
    public ArrayList<Professor> retornarProfessor(){
        return listaProfessor;
    }

    public void salvarDisciplina(Disciplinaa disciplina){
        listaDisciplinas.add(disciplina);
    }
    public ArrayList<Disciplinaa> retornarDisciplinas(){
        return listaDisciplinas;
    }
}
