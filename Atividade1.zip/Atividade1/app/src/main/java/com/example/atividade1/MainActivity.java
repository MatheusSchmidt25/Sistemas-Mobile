package com.example.atividade1;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Person;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

        private EditText Altura;
        private  EditText Peso;
        private TextView tvCalculado;
        private Button btMulher;
        private Button btHomem;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Altura = findViewById(R.id.Altura);
        Peso = findViewById(R.id.Peso);
        tvCalculado = findViewById(R.id.tvCalculado);
        btMulher = findViewById(R.id.btMulher);
        btHomem = findViewById(R.id.btHomem);

        btHomem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calcularHomem();
            }
        });
        btMulher.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calcularMulher();
            }
        });
    }

    private void calcularHomem(){
        Double peso=Double.parseDouble(Peso.getText().toString());
        Double altura=Double.parseDouble(Altura.getText().toString());


        Double imc = peso/(altura*altura);

        if(imc < 20.7){
            tvCalculado.setText("Voce esta abaixo do Peso\nIMC é de "+imc);
        } else if (imc < 26.4) {
            tvCalculado.setText("Voce esta no peso normal\nIMC é de "+imc);
        } else if (imc < 27.8) {
            tvCalculado.setText("Voce esta marginalmente acima do peso\nIMC é de "+imc);
        } else if (imc < 31.1) {
            tvCalculado.setText("Voce esta acima do peso ideal\nIMC é de "+imc);
        }else
            tvCalculado.setText("Voce esta Thais Carla\nIMC é de "+imc);
    }
    private void calcularMulher(){
        Double peso=Double.parseDouble(Peso.getText().toString());
        Double altura=Double.parseDouble(Peso.getText().toString());
        Double imc = peso/(altura*altura);

        if(imc < 20.7){
            tvCalculado.setText("Voce esta abaixo do Peso\nIMC é de "+imc);
        } else if (imc < 26.4) {
            tvCalculado.setText("Voce esta no peso normal\nIMC é de "+imc);
        } else if (imc < 27.8) {
            tvCalculado.setText("Voce esta marginalmente acima do peso\nIMC é de "+imc);
        } else if (imc < 31.1) {
            tvCalculado.setText("Voce esta acima do peso ideal\nIMC é de "+imc);
        }else
            tvCalculado.setText("Voce esta Thais Carla\nIMC é de "+imc);
    }
    private void apagarTexto() {
        tvCalculado.setText("");

    }
}