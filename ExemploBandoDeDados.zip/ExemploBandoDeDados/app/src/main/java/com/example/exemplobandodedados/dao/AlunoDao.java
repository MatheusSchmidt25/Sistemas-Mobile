package com.example.exemplobandodedados.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.exemplobandodedados.helper.SQLiteDataHelper;
import com.example.exemplobandodedados.model.Aluno;

import java.util.ArrayList;

public class AlunoDao implements GenericDao<Aluno>{

    private SQLiteOpenHelper openHelper;
    private SQLiteDatabase bd;
    private String nomeTabela = "ALUNO";
    //nome colunas da tabela
    private String[]colunas = {"RA","NOME"};
    private Context context;
    private static AlunoDao instancia;

    public static AlunoDao getInstancia(Context context){
        if(instancia == null){
            return instancia = new AlunoDao(context);
        }else{
            return instancia;
        }
    }

    private AlunoDao(Context context){
        this.context = context;

        openHelper = new SQLiteDataHelper(this.context,"UNIPAR",
                null,1);

        bd = openHelper.getWritableDatabase();
    }

    @Override
    public long insert(Aluno obj) {
        try{
            ContentValues valores = new ContentValues();
            valores.put(colunas[0], obj.getRa());
            valores.put(colunas[1], obj.getNome());

            return bd.insert(nomeTabela, null, valores);

        }catch(SQLException ex){
            Log.e("ERRO", "AlunoDao.insert(): "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public long update(Aluno obj) {
        try{
            ContentValues valores = new ContentValues();
            valores.put(colunas[1], obj.getNome());

            String[]identificador = {String.valueOf(obj.getRa())};
            bd.update(nomeTabela, valores,
                    colunas[0]+"=?", identificador);


        }catch (SQLException ex){
            Log.e("ERRO", "AlunoDao.update: "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public long delete(Aluno obj) {
      try{

          String[]identificador = {String.valueOf(obj.getRa())};
          return bd.delete(nomeTabela, colunas[0]+" = ?",
                  identificador);

      }catch (SQLException ex){
          Log.e("ERRO", "AlunoDao.delete(): "+ex.getMessage());
      }
        return 0;
    }

    @Override
    public ArrayList<Aluno> getAll() {
        ArrayList<Aluno> lista = new ArrayList<>();
        try{
            Cursor cursor = bd.query(nomeTabela, colunas,
                    null, null, null,
                    null, colunas[0]);

            if(cursor.moveToFirst()){
                do {
                    Aluno aluno = new Aluno();
                    aluno.setRa(cursor.getInt(0));
                    aluno.setNome(cursor.getString(1));

                    lista.add(aluno);

                }while (cursor.moveToNext());
            }
        }catch (SQLException ex){
            Log.e("ERRO", "AlunoDao.getAll(): "+ex.getMessage());
        }
        return null;
    }

    @Override
    public Aluno getById(int id) {
        try{
            String[]identificador = {String.valueOf(id)};
            Cursor cursor = bd.query(nomeTabela, colunas,
                    colunas[0]+" = ?", identificador,
                    null, null, null);

            if (cursor.moveToFirst()){
                Aluno aluno = new Aluno();
                aluno.setRa(cursor.getInt(0));
                aluno.setNome(cursor.getString(1));

                return  aluno;
            }

        }catch (SQLException ex){
            Log.e("ERRO", "AlunoDao.getById(): "+ex.getMessage());
        }
        return null;
    }
}
