package com.example.exemplobandodedados.view;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.exemplobandodedados.R;
import com.example.exemplobandodedados.dao.AlunoDao;
import com.example.exemplobandodedados.dao.ProfessorDao;
import com.example.exemplobandodedados.model.Aluno;
import com.example.exemplobandodedados.model.Professor;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Aluno aluno = new Aluno();
        aluno.setRa(879065);
        aluno.setNome("Coco");
        AlunoDao.getInstancia(this).insert(aluno);

        Professor professor = new Professor();
        professor.setIdProfessor(23);
        professor.setMatricula(45);
        professor.setNome("Xixi");
        ProfessorDao.getInstancia(this).insert(professor);
    }
}