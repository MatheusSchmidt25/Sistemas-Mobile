package com.example.exemplobandodedados.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.exemplobandodedados.helper.SQLiteDataHelper;
import com.example.exemplobandodedados.model.Aluno;
import com.example.exemplobandodedados.model.Disciplina;

import java.util.ArrayList;

public class DisciplinaDao implements GenericDao<Disciplina> {

    private SQLiteOpenHelper openHelper;
    private SQLiteDatabase bd;
    private String nomeTabela = "DISCIPLINA";
    private String[]colunas = {"IDDISCIPLINA","DESCRICAO","PERIODO","CARGAHORARIA"};
    private Context context;
    private static  DisciplinaDao instancia;

    public static DisciplinaDao getInstancia(Context context){
        if(instancia == null){
            return instancia = new DisciplinaDao(context);
        }else{
            return instancia;
        }
    }

    private DisciplinaDao(Context context){
        this.context = context;

        openHelper = new SQLiteDataHelper(this.context, "UNIPAR",
                null, 1);
        bd = openHelper.getWritableDatabase();
    }

    @Override
    public long insert(Disciplina obj) {
        try {
            ContentValues valores = new ContentValues();
            valores.put(colunas[0], obj.getIdDisciplina());
            valores.put(colunas[1], obj.getDescricao());
            valores.put(colunas[2], obj.getPeriodo());
            valores.put(colunas[3], obj.getCargaHoraria());

            return bd.insert(nomeTabela, null, valores);


        }catch (SQLException ex){
            Log.e("ERRO", "DisciplinaDao.insert(): "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public long update(Disciplina obj) {
        try{
            ContentValues valores = new ContentValues();
            valores.put(colunas[1], obj.getDescricao());

            String[]identificador = {String.valueOf(obj.getIdDisciplina())};
            bd.update(nomeTabela, valores,
                    colunas[0]+"=?", identificador);


        }catch (SQLException ex){
            Log.e("ERRO", "DisciplinaDao.update: "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public long delete(Disciplina obj) {
        try{

            String[]identificador = {String.valueOf(obj.getIdDisciplina())};
            return bd.delete(nomeTabela, colunas[0]+" = ?",
                    identificador);

        }catch (SQLException ex){
            Log.e("ERRO", "DisciplinaDao.delete(): "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public ArrayList<Disciplina> getAll() {
        ArrayList<Disciplina> lista = new ArrayList<>();
        try{
            Cursor cursor = bd.query(nomeTabela, colunas,
                    null, null, null,
                    null, colunas[0]);

            if(cursor.moveToFirst()){
                do {
                    Disciplina disciplina = new Disciplina();
                    disciplina.setIdDisciplina(cursor.getInt(0));
                    disciplina.setDescricao(cursor.getString(1));
                    disciplina.setPeriodo(cursor.getInt(2));
                    disciplina.setCargaHoraria(cursor.getDouble(3));

                    lista.add(disciplina);

                }while (cursor.moveToNext());
            }
        }catch (SQLException ex){
            Log.e("ERRO", "AlunoDao.getAll(): "+ex.getMessage());
        }
        return null;
    }

    @Override
    public Disciplina getById(int id) {
        try{
            String[]identificador = {String.valueOf(id)};
            Cursor cursor = bd.query(nomeTabela, colunas,
                    colunas[0]+" = ?", identificador,
                    null, null, null);

            if (cursor.moveToFirst()){
                Disciplina disciplina = new Disciplina();
                disciplina.setIdDisciplina(cursor.getInt(0));
                disciplina.setDescricao(cursor.getString(1));
                disciplina.setPeriodo(cursor.getInt(2));
                disciplina.setCargaHoraria(cursor.getDouble(3));


                return  disciplina;
            }

        }catch (SQLException ex){
            Log.e("ERRO", "AlunoDao.getById(): "+ex.getMessage());
        }
        return null;
    }
}
