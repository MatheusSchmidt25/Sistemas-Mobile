package com.example.exemplobandodedados.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.exemplobandodedados.helper.SQLiteDataHelper;
import com.example.exemplobandodedados.model.Disciplina;

import java.util.ArrayList;

public class DisciplinaDao implements GenericDao<Disciplina> {

    private SQLiteOpenHelper openHelper;
    private SQLiteDatabase bd;
    private String nomeTabela = "DISCIPLINA";
    private String[]colunas = {"IDISCIPLINA","DESCRICAO","PERIODO","CARGAHORARIA"};
    private Context context;
    private static  DisciplinaDao instancia;

    public static DisciplinaDao getInstancia(Context context){
        if(instancia == null){
            return instancia = new DisciplinaDao(context);
        }else{
            return instancia;
        }
    }

    private DisciplinaDao(Context context){
        this.context = context;

        openHelper = new SQLiteDataHelper(this.context, "UNIPAR",
                null, 1);
        bd = openHelper.getWritableDatabase();
    }

    @Override
    public long insert(Disciplina obj) {
        try {
            ContentValues valores = new ContentValues();
            valores.put(colunas[0], obj.getIdDisciplina());
            valores.put(colunas[1], obj.getDescricao());
            valores.put(colunas[2], obj.getPeriodo());
            valores.put(colunas[3], obj.getCargaHoraria());

            return bd.insert(nomeTabela, null, valores);


        }catch (SQLException ex){
            Log.e("ERRO", "DisciplinaDao.insert(): "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public long update(Disciplina obj) {
        return 0;
    }

    @Override
    public long delete(Disciplina obj) {
        return 0;
    }

    @Override
    public ArrayList<Disciplina> getAll() {
        return null;
    }

    @Override
    public Disciplina getById(int id) {
        return null;
    }
}
