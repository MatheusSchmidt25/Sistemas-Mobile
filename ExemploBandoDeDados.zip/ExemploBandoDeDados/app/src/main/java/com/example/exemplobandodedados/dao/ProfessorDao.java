package com.example.exemplobandodedados.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.exemplobandodedados.helper.SQLiteDataHelper;
import com.example.exemplobandodedados.model.Professor;

import java.util.ArrayList;

public class ProfessorDao implements  GenericDao<Professor>{

    private SQLiteOpenHelper openHelper;
    private SQLiteDatabase bd;
    private String nomeTabela = "PROFESSOR";
    private String[]colunas = {"IDPROFESSOR","MATRICULA","NOME"};
    private Context context;
    private static ProfessorDao instancia;


    public static ProfessorDao getInstancia(Context context){
        if(instancia == null){
            return instancia = new ProfessorDao(context);
        }else{
            return instancia;
        }
    }

    private ProfessorDao(Context context){
        this.context = context;

        openHelper = new SQLiteDataHelper(this.context, "UNIPAR",
                null,1);

        bd = openHelper.getWritableDatabase();
    }


    @Override
    public long insert(Professor obj) {
        try {
            ContentValues valores = new ContentValues();
            valores.put(colunas[0], obj.getIdProfessor());
            valores.put(colunas[1], obj.getMatricula());
            valores.put(colunas[2], obj.getNome());

            return bd.insert(nomeTabela, null, valores);

        }catch (SQLException ex){
            Log.e("ERRO", "AlunoDao.insert(): "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public long update(Professor obj) {
        return 0;
    }

    @Override
    public long delete(Professor obj) {
        return 0;
    }

    @Override
    public ArrayList<Professor> getAll() {
        return null;
    }

    @Override
    public Professor getById(int id) {
        return null;
    }
}
