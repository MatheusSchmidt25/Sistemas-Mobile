package com.example.exemplobandodedados.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.exemplobandodedados.helper.SQLiteDataHelper;
import com.example.exemplobandodedados.model.Disciplina;
import com.example.exemplobandodedados.model.Professor;

import java.util.ArrayList;

public class ProfessorDao implements  GenericDao<Professor>{

    private SQLiteOpenHelper openHelper;
    private SQLiteDatabase bd;
    private String nomeTabela = "PROFESSOR";
    private String[]colunas = {"IDPROFESSOR","MATRICULA","NOME"};
    private Context context;
    private static ProfessorDao instancia;


    public static ProfessorDao getInstancia(Context context){
        if(instancia == null){
            return instancia = new ProfessorDao(context);
        }else{
            return instancia;
        }
    }

    private ProfessorDao(Context context){
        this.context = context;

        openHelper = new SQLiteDataHelper(this.context, "UNIPAR",
                null,1);

        bd = openHelper.getWritableDatabase();
    }


    @Override
    public long insert(Professor obj) {
        try {
            ContentValues valores = new ContentValues();
            valores.put(colunas[0], obj.getIdProfessor());
            valores.put(colunas[1], obj.getMatricula());
            valores.put(colunas[2], obj.getNome());

            return bd.insert(nomeTabela, null, valores);

        }catch (SQLException ex){
            Log.e("ERRO", "AlunoDao.insert(): "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public long update(Professor obj) {
        try{
            ContentValues valores = new ContentValues();
            valores.put(colunas[1], obj.getMatricula());

            String[]identificador = {String.valueOf(obj.getIdProfessor())};
            bd.update(nomeTabela, valores,
                    colunas[0]+"=?", identificador);


        }catch (SQLException ex){
            Log.e("ERRO", "DisciplinaDao.update: "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public long delete(Professor obj) {
        try{

            String[]identificador = {String.valueOf(obj.getIdProfessor())};
            return bd.delete(nomeTabela, colunas[0]+" = ?",
                    identificador);

        }catch (SQLException ex){
            Log.e("ERRO", "AlunoDao.delete(): "+ex.getMessage());
        }
        return 0;
    }

    @Override
    public ArrayList<Professor> getAll() {
        ArrayList<Professor> lista = new ArrayList<>();
        try{
            Cursor cursor = bd.query(nomeTabela, colunas,
                    null, null, null,
                    null, colunas[0]);

            if(cursor.moveToFirst()){
                do {
                    Professor professor = new Professor();
                    professor.setIdProfessor(cursor.getInt(0));
                    professor.setMatricula(cursor.getInt(1));
                    professor.setNome(cursor.getString(2));


                    lista.add(professor);

                }while (cursor.moveToNext());
            }
        }catch (SQLException ex){
            Log.e("ERRO", "AlunoDao.getAll(): "+ex.getMessage());
        }
        return null;
    }

    @Override
    public Professor getById(int id) {
        try{
            String[]identificador = {String.valueOf(id)};
            Cursor cursor = bd.query(nomeTabela, colunas,
                    colunas[0]+" = ?", identificador,
                    null, null, null);

            if (cursor.moveToFirst()){
                Professor professor = new Professor();
                professor.setIdProfessor(cursor.getInt(0));
                professor.setMatricula(cursor.getInt(1));
                professor.setNome(cursor.getString(2));


                return  professor;
            }

        }catch (SQLException ex){
            Log.e("ERRO", "AlunoDao.getById(): "+ex.getMessage());
        }
        return null;
    }
}
