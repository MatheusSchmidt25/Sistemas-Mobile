package com.example.exemplobandodedados.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.exemplobandodedados.helper.SQLiteDataHelper;
import com.example.exemplobandodedados.model.Turma;
import java.util.ArrayList;

public class TurmaDao implements GenericDao<Turma> {

    private SQLiteOpenHelper openHelper;
    private SQLiteDatabase bd;
    private String nomeTabela = "TURMA";
    private String[]colunas = {"IDTURMA","CURSO","ANOINICIO","ANOFIM"};
    private Context context;
    private static TurmaDao instancia;

    public static  TurmaDao getInstancia(Context context){
        if(instancia == null){
            return instancia = new TurmaDao(context);
        }else{
            return instancia;
        }
    }

    private TurmaDao(Context context){
        this.context = context;

        openHelper = new SQLiteDataHelper(this.context, "UNIPAR",
                null, 1);

        bd = openHelper.getWritableDatabase();
    }

    public long insert(Turma obj) {
        try{
            ContentValues valores = new ContentValues();
            valores.put(colunas[0], obj.getIdTurma());
            valores.put(colunas[1], obj.getCurso());
            valores.put(colunas[2], obj.getAnoInicio());
            valores.put(colunas[3], obj.getAnoFim());

            return bd.insert(nomeTabela, null, valores);

        }catch(SQLException ex){
            Log.e("ERRO", "TurmaDao.insert(): "+ex.getMessage());
        }
        return 0;
    }

    public long update(Turma obj) {
        return 0;
    }

    public long delete(Turma obj) {
        return 0;
    }

    public ArrayList<Turma> getAll() {
        return null;
    }

    public Turma getById(int id) {
        return null;
    }

}
