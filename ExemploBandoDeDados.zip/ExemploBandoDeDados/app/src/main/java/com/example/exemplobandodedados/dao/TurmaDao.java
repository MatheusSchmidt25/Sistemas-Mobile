package com.example.exemplobandodedados.dao;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import com.example.exemplobandodedados.helper.SQLiteDataHelper;
import com.example.exemplobandodedados.model.Disciplina;
import com.example.exemplobandodedados.model.Turma;
import java.util.ArrayList;

public class TurmaDao implements GenericDao<Turma> {

    private SQLiteOpenHelper openHelper;
    private SQLiteDatabase bd;
    private String nomeTabela = "TURMA";
    private String[]colunas = {"IDTURMA","CURSO","ANOINICIO","ANOFIM"};
    private Context context;
    private static TurmaDao instancia;

    public static  TurmaDao getInstancia(Context context){
        if(instancia == null){
            return instancia = new TurmaDao(context);
        }else{
            return instancia;
        }
    }

    private TurmaDao(Context context){
        this.context = context;

        openHelper = new SQLiteDataHelper(this.context, "UNIPAR",
                null, 1);

        bd = openHelper.getWritableDatabase();
    }

    public long insert(Turma obj) {
        try{
            ContentValues valores = new ContentValues();
            valores.put(colunas[0], obj.getIdTurma());
            valores.put(colunas[1], obj.getCurso());
            valores.put(colunas[2], obj.getAnoInicio());
            valores.put(colunas[3], obj.getAnoFim());

            return bd.insert(nomeTabela, null, valores);

        }catch(SQLException ex){
            Log.e("ERRO", "TurmaDao.insert(): "+ex.getMessage());
        }
        return 0;
    }

    public long update(Turma obj) {
        try{
            ContentValues valores = new ContentValues();
            valores.put(colunas[1], obj.getCurso());

            String[]identificador = {String.valueOf(obj.getIdTurma())};
            bd.update(nomeTabela, valores,
                    colunas[0]+"=?", identificador);


        }catch (SQLException ex){
            Log.e("ERRO", "DisciplinaDao.update: "+ex.getMessage());
        }
        return 0;
    }

    public long delete(Turma obj) {
        try{

            String[]identificador = {String.valueOf(obj.getIdTurma())};
            return bd.delete(nomeTabela, colunas[0]+" = ?",
                    identificador);

        }catch (SQLException ex){
            Log.e("ERRO", "TurmaDao.delete(): "+ex.getMessage());
        }
        return 0;
    }

    public ArrayList<Turma> getAll() {
        ArrayList<Turma> lista = new ArrayList<>();
        try{
            Cursor cursor = bd.query(nomeTabela, colunas,
                    null, null, null,
                    null, colunas[0]);

            if(cursor.moveToFirst()){
                do {
                    Turma turma = new Turma();
                    turma.setIdTurma(cursor.getInt(0));
                    turma.setCurso(cursor.getString(1));
                    turma.setAnoInicio(cursor.getInt(2));
                    turma.setAnoFim(cursor.getInt(3));

                    lista.add(turma);

                }while (cursor.moveToNext());
            }
        }catch (SQLException ex){
            Log.e("ERRO", "AlunoDao.getAll(): "+ex.getMessage());
        }
        return null;
    }

    public Turma getById(int id) {
        try{
            String[]identificador = {String.valueOf(id)};
            Cursor cursor = bd.query(nomeTabela, colunas,
                    colunas[0]+" = ?", identificador,
                    null, null, null);

            if (cursor.moveToFirst()){
                Turma turma = new Turma();
                turma.setIdTurma(cursor.getInt(0));
                turma.setCurso(cursor.getString(1));
                turma.setAnoInicio(cursor.getInt(2));
                turma.setAnoFim(cursor.getInt(3));


                return  turma;
            }

        }catch (SQLException ex){
            Log.e("ERRO", "AlunoDao.getById(): "+ex.getMessage());
        }
        return null;
    }

}
