package com.example.atividade2;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText edRenda;
    private EditText etDependentes;
    private EditText etValor;
    private Button btCalcular;
    private EditText etResultado;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edRenda = findViewById(R.id.edRenda);
        etDependentes = findViewById(R.id.etDependentes);
        etValor = findViewById(R.id.etValor);
        btCalcular = findViewById(R.id.btCalcular);
        etResultado = findViewById(R.id.etResultado);

        btCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculo();
            }
        });
    }



    private void calculo(){
        Double renda = Double.parseDouble(edRenda.getText().toString());
        Double dependentes=Double.parseDouble(etDependentes.getText().toString());
        Double valor=Double.parseDouble(etValor.getText().toString());

        Double pessoas=dependentes*300.00*12;
        Double rendaAnual=renda*12;
        Double excedente=rendaAnual-18.000;
        Double quinze=excedente*0.15;
        Double impostoMaior=(excedente*0.275)+1.350;
        impostoMaior-=pessoas;
        Double baseCalculo=rendaAnual-excedente-valor;
        Double impostoQuinze=excedente*0.15;
        impostoQuinze-=excedente;


        if(rendaAnual <= 18.000){
            etResultado.setText("Seu imposto é 0");
        } else if (rendaAnual <= 27.000) {
            etResultado.setText("Renda Bruta Anual:"+rendaAnual+"\nBase de Calculo "+baseCalculo+"\nImposto Devido "+impostoQuinze);
        } else if (rendaAnual > 27.000) {
            etResultado.setText("Renda Bruta Anual:"+rendaAnual+"\nBase de Calculo "+baseCalculo+"\nImposto Devido "+impostoQuinze);
        }

    }
}